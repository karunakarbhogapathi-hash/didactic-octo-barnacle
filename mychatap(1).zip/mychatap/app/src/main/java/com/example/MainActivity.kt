package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.DonutLarge
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.DonutLarge
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.GoogleAuthManager
import com.example.auth.authStateFlow
import com.example.data.repository.ChatRepository
import com.example.ui.components.AvatarImage
import com.example.ui.screens.ActiveCallOverlay
import com.example.ui.screens.CallsScreen
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.ChatsListScreen
import com.example.ui.screens.SettingsProfileScreen
import com.example.ui.screens.StatusUpdatesScreen
import com.example.ui.screens.WelcomeAuthScreen
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.LocalChatColors
import com.example.ui.theme.MyChatApTheme
import com.example.util.NotificationHelper
import com.example.viewmodel.AppNotificationEvent
import com.example.viewmodel.MyChatViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        NotificationHelper.ensureChannelsCreated(this)

        setContent {
            MyChatApRoot()
        }
    }
}

@Composable
fun MyChatApRoot() {
    val auth = Firebase.auth
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        MyChatApTheme {
            WelcomeAuthScreen(onAuthSuccess = { /* AuthStateListener updates currentUser */ })
        }
    } else {
        AuthenticatedAppShell(user = user)
    }
}

private enum class MainTab(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    CHATS("tab_chats", R.string.tab_chats, Icons.Filled.Chat, Icons.Outlined.Chat),
    STATUS("tab_status", R.string.tab_updates, Icons.Filled.DonutLarge, Icons.Outlined.DonutLarge),
    CALLS("tab_calls", R.string.tab_calls, Icons.Filled.Call, Icons.Outlined.Call),
    SETTINGS("tab_settings", R.string.tab_settings, Icons.Filled.Settings, Icons.Outlined.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedAppShell(user: FirebaseUser) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: MyChatViewModel = viewModel(
        key = user.uid,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                MyChatViewModel(
                    repository = ChatRepository(db),
                    currentUserId = user.uid,
                    initialDisplayName = user.displayName ?: "",
                    initialEmail = user.email ?: "",
                    initialPhotoUrl = user.photoUrl?.toString() ?: ""
                )
            }
        }
    )

    val myProfile by viewModel.myProfile.collectAsStateWithLifecycle()
    val privateSettings by viewModel.myPrivateSettings.collectAsStateWithLifecycle()
    val profilesMap by viewModel.profilesMap.collectAsStateWithLifecycle()
    val chatsState by viewModel.chatsState.collectAsStateWithLifecycle()
    val statusesState by viewModel.statusesState.collectAsStateWithLifecycle()
    val callsState by viewModel.callsState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedChatFilter.collectAsStateWithLifecycle()
    val activeChatId by viewModel.activeChatId.collectAsStateWithLifecycle()
    val activeChatRoom by viewModel.activeChatRoom.collectAsStateWithLifecycle()
    val activeMessagesState by viewModel.activeMessagesState.collectAsStateWithLifecycle()
    val activeCallSession by viewModel.activeCallSession.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var currentTab by rememberSaveable { mutableStateOf(MainTab.CHATS) }

    androidx.activity.compose.BackHandler(enabled = activeChatId == null && currentTab != MainTab.CHATS) {
        currentTab = MainTab.CHATS
    }

    // Request POST_NOTIFICATIONS once on Android 13+ after login
    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(user.uid) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !NotificationHelper.canPostNotifications(context)
        ) {
            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Track real-time online/last-seen presence with Android Activity Lifecycle
    DisposableEffect(lifecycleOwner, user.uid) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> viewModel.setOnlinePresence(true)
                Lifecycle.Event.ON_STOP -> viewModel.setOnlinePresence(false)
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Collect notification events
    LaunchedEffect(viewModel) {
        viewModel.notificationEvents.collect { event ->
            when (event) {
                is AppNotificationEvent.NewMessage -> {
                    NotificationHelper.showMessageNotification(
                        context = context,
                        notificationId = event.notificationId,
                        senderName = event.senderName,
                        messageText = event.previewText
                    )
                }
                is AppNotificationEvent.IncomingCall -> {
                    NotificationHelper.showIncomingCallNotification(
                        context = context,
                        callIdHash = event.callIdHash,
                        callerName = event.callerName,
                        callType = event.callType
                    )
                }
            }
        }
    }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    MyChatApTheme(darkModePreference = privateSettings?.darkModePreference ?: "system") {
        val chatColors = LocalChatColors.current

        Box(modifier = Modifier.fillMaxSize()) {
            if (activeChatId != null) {
                ChatDetailScreen(
                    currentUserId = user.uid,
                    chatRoom = activeChatRoom,
                    messagesState = activeMessagesState,
                    profilesMap = profilesMap,
                    onBack = { viewModel.closeActiveChat() },
                    onSendMessage = { type, text, img, replyId, replyPreview ->
                        viewModel.sendMessage(type, text, img, replyId, replyPreview)
                    },
                    onDeleteMessage = { msgId -> viewModel.deleteMessage(msgId) },
                    onTypingChanged = { typing -> viewModel.onTypingChanged(typing) },
                    onStartCall = { peer, callType -> viewModel.initiateCall(peer, callType) },
                    onUpdateGroup = { title, desc, photo, participants, admins ->
                        activeChatId?.let { cid ->
                            viewModel.updateGroupDetails(cid, title, desc, photo, participants, admins)
                        }
                    }
                )
            } else {
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val isExpandedScreen = maxWidth >= 600.dp

                    Row(modifier = Modifier.fillMaxSize()) {
                        if (isExpandedScreen) {
                            NavigationRail(
                                containerColor = MaterialTheme.colorScheme.surface
                            ) {
                                MainTab.entries.forEach { tab ->
                                    val selected = currentTab == tab
                                    NavigationRailItem(
                                        selected = selected,
                                        onClick = { currentTab = tab },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = stringResource(tab.labelRes)
                                            )
                                        },
                                        label = { Text(stringResource(tab.labelRes)) },
                                        modifier = Modifier.testTag(tab.route)
                                    )
                                }
                            }
                        }

                        Scaffold(
                            contentWindowInsets = WindowInsets(0, 0, 0, 0),
                            snackbarHost = { SnackbarHost(snackbarHostState) },
                            topBar = {
                                TopAppBar(
                                    title = {
                                        Text(
                                            text = stringResource(R.string.app_name),
                                            fontWeight = FontWeight.Bold
                                        )
                                    },
                                    actions = {
                                        val me = myProfile
                                        if (me != null) {
                                            IconButtonAvatar(
                                                photoData = me.photoData,
                                                displayName = me.displayName,
                                                onClick = { currentTab = MainTab.SETTINGS }
                                            )
                                        }
                                    },
                                    colors = TopAppBarDefaults.topAppBarColors(
                                        containerColor = chatColors.topBarBackground,
                                        titleContentColor = chatColors.topBarContent,
                                        actionIconContentColor = chatColors.topBarContent
                                    )
                                )
                            },
                            bottomBar = {
                                if (!isExpandedScreen) {
                                    NavigationBar(
                                        containerColor = MaterialTheme.colorScheme.surface,
                                        tonalElevation = 4.dp
                                    ) {
                                        MainTab.entries.forEach { tab ->
                                            val selected = currentTab == tab
                                            NavigationBarItem(
                                                selected = selected,
                                                onClick = { currentTab = tab },
                                                icon = {
                                                    Icon(
                                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                        contentDescription = stringResource(tab.labelRes)
                                                    )
                                                },
                                                label = { Text(stringResource(tab.labelRes)) },
                                                colors = NavigationBarItemDefaults.colors(
                                                    indicatorColor = EmeraldAccent.copy(alpha = 0.24f)
                                                ),
                                                modifier = Modifier.testTag(tab.route)
                                            )
                                        }
                                    }
                                }
                            }
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                when (currentTab) {
                                    MainTab.CHATS -> ChatsListScreen(
                                        currentUserId = user.uid,
                                        chatsState = chatsState,
                                        profilesMap = profilesMap,
                                        searchQuery = searchQuery,
                                        selectedFilter = selectedFilter,
                                        isBusy = isBusy,
                                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                                        onFilterChange = { viewModel.setChatFilter(it) },
                                        onOpenChat = { cid -> viewModel.openChat(cid) },
                                        onStartDirectChat = { contact ->
                                            viewModel.startOrOpenDirectChat(contact) { /* opened */ }
                                        },
                                        onCreateGroup = { title, desc, photo, memberIds ->
                                            viewModel.createGroupChat(title, desc, photo, memberIds) { /* opened */ }
                                        }
                                    )
                                    MainTab.STATUS -> StatusUpdatesScreen(
                                        currentUserId = user.uid,
                                        myProfile = myProfile,
                                        statusesState = statusesState,
                                        onPostStatus = { mediaType, caption, imageData, bgHex ->
                                            viewModel.postStatus(mediaType, caption, imageData, bgHex)
                                        },
                                        onMarkViewed = { status -> viewModel.markStatusViewed(status) },
                                        onDeleteStatus = { statusId -> viewModel.deleteStatus(statusId) }
                                    )
                                    MainTab.CALLS -> CallsScreen(
                                        currentUserId = user.uid,
                                        callsState = callsState,
                                        profilesMap = profilesMap,
                                        onStartCall = { peer, callType -> viewModel.initiateCall(peer, callType) }
                                    )
                                    MainTab.SETTINGS -> SettingsProfileScreen(
                                        myProfile = myProfile,
                                        privateSettings = privateSettings,
                                        isBusy = isBusy,
                                        onSave = { name, handle, about, photo, lastSeen, disc, phone, receipts, notif, callNotif, theme ->
                                            viewModel.saveProfileAndPrivacy(
                                                name, handle, about, photo, lastSeen, disc,
                                                phone, receipts, notif, callNotif, theme
                                            )
                                        },
                                        onSignOut = {
                                            viewModel.setOnlinePresence(false)
                                            GoogleAuthManager.signOut(credentialManager, scope) { }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Full-Screen Active / Incoming Call Overlay
            activeCallSession?.let { call ->
                ActiveCallOverlay(
                    currentUserId = user.uid,
                    call = call,
                    onAnswer = { viewModel.answerIncomingCall(call) },
                    onDecline = { viewModel.declineIncomingCall(call) },
                    onUpdateMedia = { muted, videoOn -> viewModel.updateCallMedia(call, muted, videoOn) },
                    onEndCall = { duration -> viewModel.endActiveCall(call, duration) },
                    onDismissTerminal = { viewModel.dismissFinishedCallOverlay() }
                )
            }
        }
    }
}

@Composable
private fun IconButtonAvatar(
    photoData: String,
    displayName: String,
    onClick: () -> Unit
) {
    androidx.compose.material3.IconButton(
        onClick = onClick,
        modifier = Modifier
            .padding(end = 6.dp)
            .size(48.dp)
            .testTag("top_bar_profile_button")
    ) {
        AvatarImage(
            photoData = photoData,
            displayName = displayName,
            size = 34.dp
        )
    }
}
