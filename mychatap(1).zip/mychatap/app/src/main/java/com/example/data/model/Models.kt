package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val handle: String = "",
    val about: String = "Hey there! I am using MyChatAp.",
    val photoData: String = "",
    @get:PropertyName("isOnline") @set:PropertyName("isOnline")
    var isOnline: Boolean = false,
    val showLastSeen: Boolean = true,
    @get:PropertyName("isDiscoverable") @set:PropertyName("isDiscoverable")
    var isDiscoverable: Boolean = true,
    @ServerTimestamp val lastSeenAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class UserPrivateSettings(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val readReceiptsEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val callNotificationsEnabled: Boolean = true,
    val darkModePreference: String = "system",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class ChatRoom(
    @DocumentId val id: String = "",
    val chatType: String = "direct", // "direct" | "group"
    val directPairKey: String = "",
    val title: String = "",
    val description: String = "",
    val photoData: String = "",
    val createdBy: String = "",
    val participantIds: List<String> = emptyList(),
    val adminIds: List<String> = emptyList(),
    val lastMessageText: String = "",
    val lastMessageSenderId: String = "",
    val lastMessageSenderName: String = "",
    val lastMessageType: String = "none", // "none" | "text" | "emoji" | "image"
    val typingUserIds: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    val isGroup: Boolean get() = chatType == "group"
}

@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val chatId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val participantIds: List<String> = emptyList(),
    val type: String = "text", // "text" | "emoji" | "image"
    val text: String = "",
    val imageData: String = "",
    val replyToMessageId: String = "",
    val replyPreviewText: String = "",
    val status: String = "sent", // "sent" | "delivered" | "read"
    val deliveredTo: List<String> = emptyList(),
    val readBy: List<String> = emptyList(),
    @get:PropertyName("isEdited") @set:PropertyName("isEdited")
    var isEdited: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class StatusPost(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorPhotoData: String = "",
    val mediaType: String = "text", // "text" | "image"
    val caption: String = "",
    val imageData: String = "",
    val backgroundColorHex: String = "#075E54",
    val visibility: String = "contacts", // "contacts" | "private"
    val viewerIds: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class CallSession(
    @DocumentId val id: String = "",
    val callerId: String = "",
    val callerName: String = "",
    val callerPhotoData: String = "",
    val receiverId: String = "",
    val receiverName: String = "",
    val receiverPhotoData: String = "",
    val participantIds: List<String> = emptyList(),
    val callType: String = "audio", // "audio" | "video"
    val status: String = "ringing", // "ringing" | "accepted" | "declined" | "ended" | "missed"
    val sdpOffer: String = "",
    val sdpAnswer: String = "",
    @get:PropertyName("isMutedCaller") @set:PropertyName("isMutedCaller")
    var isMutedCaller: Boolean = false,
    @get:PropertyName("isMutedReceiver") @set:PropertyName("isMutedReceiver")
    var isMutedReceiver: Boolean = false,
    @get:PropertyName("isVideoEnabledCaller") @set:PropertyName("isVideoEnabledCaller")
    var isVideoEnabledCaller: Boolean = false,
    @get:PropertyName("isVideoEnabledReceiver") @set:PropertyName("isVideoEnabledReceiver")
    var isVideoEnabledReceiver: Boolean = false,
    val durationSeconds: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)
