package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.AddIcCall
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.CallSession
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.components.AvatarImage
import com.example.ui.theme.CallDangerRed
import com.example.ui.theme.EmeraldAccent
import com.example.util.TimeFormatUtils

@Composable
fun CallsScreen(
    currentUserId: String,
    callsState: UiState<List<CallSession>>,
    profilesMap: Map<String, UserProfile>,
    onStartCall: (UserProfile, String) -> Unit
) {
    var showContactPicker by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
                .align(Alignment.TopCenter)
        ) {
            when (callsState) {
                is UiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = EmeraldAccent)
                    }
                }
                is UiState.Error -> {
                    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(callsState.message, color = MaterialTheme.colorScheme.error)
                    }
                }
                is UiState.Success -> {
                    val calls = callsState.data
                    if (calls.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Call,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(52.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "No recent calls",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Start a real-time audio or video call with any MyChatAp contact using the call button below.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(bottom = 92.dp)
                        ) {
                            items(calls, key = { it.id }) { call ->
                                val isOutgoing = call.callerId == currentUserId
                                val peerId = if (isOutgoing) call.receiverId else call.callerId
                                val peerName = if (isOutgoing) call.receiverName else call.callerName
                                val peerPhoto = if (isOutgoing) call.receiverPhotoData else call.callerPhotoData
                                val isMissedOrDeclined = call.status in listOf("missed", "declined")

                                val peerProfile = profilesMap[peerId] ?: UserProfile(
                                    id = peerId,
                                    userId = peerId,
                                    displayName = peerName,
                                    photoData = peerPhoto
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp)
                                ) {
                                    AvatarImage(
                                        photoData = peerPhoto,
                                        displayName = peerName,
                                        size = 48.dp,
                                        isOnline = peerProfile.isOnline && peerProfile.showLastSeen
                                    )
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = peerName,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = if (isMissedOrDeclined && !isOutgoing) CallDangerRed
                                            else MaterialTheme.colorScheme.onSurface
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = when {
                                                    isMissedOrDeclined -> Icons.AutoMirrored.Filled.CallMissed
                                                    isOutgoing -> Icons.AutoMirrored.Filled.CallMade
                                                    else -> Icons.AutoMirrored.Filled.CallReceived
                                                },
                                                contentDescription = null,
                                                tint = if (isMissedOrDeclined) CallDangerRed else EmeraldAccent,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(5.dp))
                                            val durLabel = if (call.durationSeconds > 0) {
                                                " • ${TimeFormatUtils.formatDurationSeconds(call.durationSeconds)}"
                                            } else " • ${call.status}"
                                            Text(
                                                text = "${TimeFormatUtils.formatChatListTime(call.createdAt)}$durLabel",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    IconButton(onClick = { onStartCall(peerProfile, call.callType) }) {
                                        Icon(
                                            imageVector = if (call.callType == "video") Icons.Filled.Videocam else Icons.Filled.Call,
                                            contentDescription = "Redial $peerName",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                HorizontalDivider(
                                    modifier = Modifier.padding(start = 78.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showContactPicker = true },
            containerColor = EmeraldAccent,
            contentColor = Color(0xFF043927),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(18.dp)
                .testTag("new_call_fab")
        ) {
            Icon(Icons.Filled.AddIcCall, contentDescription = "Start new call")
        }
    }

    if (showContactPicker) {
        val contacts = remember(profilesMap, currentUserId) {
            profilesMap.values.filter { (it.userId.ifBlank { it.id }) != currentUserId }
        }
        AlertDialog(
            onDismissRequest = { showContactPicker = false },
            title = { Text("Select Contact to Call") },
            text = {
                if (contacts.isEmpty()) {
                    Text("No other discoverable contacts yet.")
                } else {
                    LazyColumn(modifier = Modifier.height(260.dp)) {
                        items(contacts, key = { it.userId.ifBlank { it.id } }) { contact ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showContactPicker = false
                                        onStartCall(contact, "audio")
                                    }
                                    .padding(vertical = 8.dp)
                            ) {
                                AvatarImage(
                                    photoData = contact.photoData,
                                    displayName = contact.displayName,
                                    size = 40.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = contact.displayName,
                                    style = MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(onClick = {
                                    showContactPicker = false
                                    onStartCall(contact, "audio")
                                }) {
                                    Icon(Icons.Filled.Call, contentDescription = "Audio call")
                                }
                                IconButton(onClick = {
                                    showContactPicker = false
                                    onStartCall(contact, "video")
                                }) {
                                    Icon(Icons.Filled.Videocam, contentDescription = "Video call")
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showContactPicker = false }) {
                    Text("Close")
                }
            }
        )
    }
}
