package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.ChatRoom
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.components.AvatarImage
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldDeep
import com.example.util.TimeFormatUtils

@Composable
fun ChatsListScreen(
    currentUserId: String,
    chatsState: UiState<List<ChatRoom>>,
    profilesMap: Map<String, UserProfile>,
    searchQuery: String,
    selectedFilter: String,
    isBusy: Boolean,
    onSearchQueryChange: (String) -> Unit,
    onFilterChange: (String) -> Unit,
    onOpenChat: (String) -> Unit,
    onStartDirectChat: (UserProfile) -> Unit,
    onCreateGroup: (title: String, description: String, photoData: String, memberIds: List<String>) -> Unit
) {
    var showNewChatSheet by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
                .align(Alignment.TopCenter)
        ) {
            // Search Bar & Filter Pills
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text(stringResource(R.string.search_chats_placeholder)) },
                    leadingIcon = {
                        Icon(Icons.Filled.Search, contentDescription = "Search")
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(50),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
                        unfocusedBorderColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_chats_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "all" to "All",
                        "direct" to "Direct",
                        "groups" to "Groups"
                    ).forEach { (key, label) ->
                        FilterChip(
                            selected = selectedFilter == key,
                            onClick = { onFilterChange(key) },
                            label = { Text(label) }
                        )
                    }
                }
            }

            when (chatsState) {
                is UiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = EmeraldAccent)
                    }
                }
                is UiState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = chatsState.message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center
                        )
                    }
                }
                is UiState.Success -> {
                    val q = searchQuery.trim().lowercase()
                    val filteredChats = remember(chatsState.data, profilesMap, q, selectedFilter) {
                        chatsState.data.filter { chat ->
                            val matchesFilter = when (selectedFilter) {
                                "groups" -> chat.isGroup
                                "direct" -> !chat.isGroup
                                else -> true
                            }
                            if (!matchesFilter) return@filter false
                            if (q.isEmpty()) return@filter true

                            val peerProfile = if (!chat.isGroup) {
                                val otherUid = chat.participantIds.firstOrNull { it != currentUserId }
                                otherUid?.let { profilesMap[it] }
                            } else null

                            val resolvedTitle = peerProfile?.displayName?.ifBlank { chat.title } ?: chat.title
                            resolvedTitle.lowercase().contains(q) ||
                                chat.lastMessageText.lowercase().contains(q) ||
                                (peerProfile?.handle?.lowercase()?.contains(q) == true)
                        }
                    }

                    // Matching global contacts not yet chatted with when searching
                    val matchingContacts = remember(profilesMap, q, currentUserId) {
                        if (q.isEmpty()) emptyList()
                        else profilesMap.values.filter { p ->
                            val uid = p.userId.ifBlank { p.id }
                            uid != currentUserId && (
                                p.displayName.lowercase().contains(q) ||
                                    p.handle.lowercase().contains(q)
                                )
                        }
                    }

                    if (filteredChats.isEmpty() && matchingContacts.isEmpty()) {
                        EmptyChatsState(
                            hasSearchQuery = q.isNotEmpty(),
                            onNewChatClick = { showNewChatSheet = true }
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(bottom = 92.dp)
                        ) {
                            items(filteredChats, key = { it.id }) { chat ->
                                ChatRoomRow(
                                    chat = chat,
                                    currentUserId = currentUserId,
                                    profilesMap = profilesMap,
                                    onClick = { onOpenChat(chat.id) }
                                )
                                HorizontalDivider(
                                    modifier = Modifier.padding(start = 78.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                                )
                            }

                            if (matchingContacts.isNotEmpty()) {
                                item {
                                    Text(
                                        text = "Directory Contacts",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                                    )
                                }
                                items(matchingContacts, key = { "dir_${it.userId.ifBlank { it.id }}" }) { contact ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onStartDirectChat(contact) }
                                            .padding(horizontal = 16.dp, vertical = 10.dp)
                                    ) {
                                        AvatarImage(
                                            photoData = contact.photoData,
                                            displayName = contact.displayName,
                                            size = 46.dp,
                                            isOnline = contact.isOnline && contact.showLastSeen
                                        )
                                        Spacer(modifier = Modifier.width(14.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = contact.displayName,
                                                style = MaterialTheme.typography.titleMedium
                                            )
                                            Text(
                                                text = "@${contact.handle} • Tap to message",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showNewChatSheet = true },
            containerColor = EmeraldAccent,
            contentColor = Color(0xFF043927),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(18.dp)
                .testTag("new_chat_fab")
        ) {
            Icon(
                imageVector = Icons.Filled.AddComment,
                contentDescription = stringResource(R.string.new_chat_fab_desc)
            )
        }
    }

    if (showNewChatSheet) {
        NewChatAndGroupSheet(
            currentUserId = currentUserId,
            contacts = profilesMap.values.toList(),
            isBusy = isBusy,
            onDismiss = { showNewChatSheet = false },
            onStartDirectChat = { contact ->
                showNewChatSheet = false
                onStartDirectChat(contact)
            },
            onCreateGroup = { title, desc, photo, memberIds ->
                showNewChatSheet = false
                onCreateGroup(title, desc, photo, memberIds)
            }
        )
    }
}

@Composable
private fun ChatRoomRow(
    chat: ChatRoom,
    currentUserId: String,
    profilesMap: Map<String, UserProfile>,
    onClick: () -> Unit
) {
    val peerProfile = remember(chat, profilesMap, currentUserId) {
        if (!chat.isGroup) {
            val otherUid = chat.participantIds.firstOrNull { it != currentUserId }
            otherUid?.let { profilesMap[it] }
        } else null
    }

    val displayTitle = when {
        chat.isGroup -> chat.title.ifBlank { "Group Chat" }
        peerProfile != null -> peerProfile.displayName.ifBlank { chat.title }
        else -> chat.title.ifBlank { "Conversation" }
    }

    val avatarPhoto = if (chat.isGroup) chat.photoData else (peerProfile?.photoData ?: "")
    val isPeerOnline = !chat.isGroup && peerProfile?.isOnline == true && peerProfile.showLastSeen
    val othersTyping = chat.typingUserIds.filterNot { it == currentUserId }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("chat_item_${chat.id}")
    ) {
        AvatarImage(
            photoData = avatarPhoto,
            displayName = displayTitle,
            size = 52.dp,
            isGroup = chat.isGroup,
            isOnline = isPeerOnline
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = displayTitle,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = TimeFormatUtils.formatChatListTime(chat.updatedAt ?: chat.createdAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(3.dp))

            if (othersTyping.isNotEmpty()) {
                Text(
                    text = "typing…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = EmeraldAccent,
                    fontWeight = FontWeight.SemiBold,
                    fontStyle = FontStyle.Italic
                )
            } else {
                val subtitle = when {
                    chat.lastMessageText.isBlank() -> "Tap to say hello 👋"
                    chat.isGroup && chat.lastMessageSenderName.isNotBlank() && chat.lastMessageSenderName != "System" ->
                        "${if (chat.lastMessageSenderId == currentUserId) "You" else chat.lastMessageSenderName}: ${chat.lastMessageText}"
                    chat.lastMessageSenderId == currentUserId -> "You: ${chat.lastMessageText}"
                    else -> chat.lastMessageText
                }
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun EmptyChatsState(
    hasSearchQuery: Boolean,
    onNewChatClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            tonalElevation = 2.dp
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_chats),
                contentDescription = "No chats yet illustration",
                modifier = Modifier
                    .width(210.dp)
                    .height(155.dp)
                    .clip(RoundedCornerShape(24.dp)),
                contentScale = ContentScale.Crop
            )
        }
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = if (hasSearchQuery) "No matching conversations" else stringResource(R.string.empty_chats_title),
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = if (hasSearchQuery) "Try searching by another contact name or @handle."
            else stringResource(R.string.empty_chats_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        if (!hasSearchQuery) {
            Spacer(modifier = Modifier.height(18.dp))
            Button(
                onClick = onNewChatClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldDeep,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("empty_state_new_chat_button")
            ) {
                Text("Start a Conversation")
            }
        }
    }
}
