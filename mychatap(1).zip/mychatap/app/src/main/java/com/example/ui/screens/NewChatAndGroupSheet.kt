package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.UserProfile
import com.example.ui.components.AvatarImage
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldDeep
import com.example.util.MediaUtils
import com.example.util.TimeFormatUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NewChatAndGroupSheet(
    currentUserId: String,
    contacts: List<UserProfile>,
    isBusy: Boolean,
    onDismiss: () -> Unit,
    onStartDirectChat: (UserProfile) -> Unit,
    onCreateGroup: (title: String, description: String, photoData: String, memberIds: List<String>) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isGroupMode by remember { mutableStateOf(false) }
    var contactQuery by remember { mutableStateOf("") }
    var groupTitle by remember { mutableStateOf("") }
    var groupDesc by remember { mutableStateOf("") }
    var groupPhotoData by remember { mutableStateOf("") }
    val selectedMemberIds = remember { mutableStateListOf<String>() }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val encoded = MediaUtils.encodeUriToDataUri(context, uri, maxDimension = 256)
                if (encoded != null) groupPhotoData = encoded
            }
        }
    }

    val availableContacts = remember(contacts, currentUserId, contactQuery) {
        val q = contactQuery.trim().lowercase()
        contacts.filter { profile ->
            val uid = profile.userId.ifBlank { profile.id }
            uid.isNotBlank() && uid != currentUserId && (
                q.isEmpty() ||
                    profile.displayName.lowercase().contains(q) ||
                    profile.handle.lowercase().contains(q) ||
                    profile.about.lowercase().contains(q)
                )
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilterChip(
                    selected = !isGroupMode,
                    onClick = { isGroupMode = false },
                    label = { Text("Direct Message") },
                    leadingIcon = {
                        Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                    },
                    modifier = Modifier.testTag("mode_direct_chat_chip")
                )
                FilterChip(
                    selected = isGroupMode,
                    onClick = { isGroupMode = true },
                    label = { Text("New Group") },
                    leadingIcon = {
                        Icon(Icons.Filled.GroupAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                    },
                    modifier = Modifier.testTag("mode_group_chat_chip")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (isGroupMode) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AvatarImage(
                        photoData = groupPhotoData,
                        displayName = groupTitle.ifBlank { "Group" },
                        size = 56.dp,
                        isGroup = true,
                        modifier = Modifier.clickable {
                            photoPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = groupTitle,
                            onValueChange = { groupTitle = it },
                            label = { Text("Group Subject") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("group_subject_input")
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = groupDesc,
                            onValueChange = { groupDesc = it },
                            label = { Text("Group Description (Optional)") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                AssistChip(
                    onClick = {
                        photoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    label = { Text(if (groupPhotoData.isEmpty()) "Set Group Icon" else "Change Group Icon") },
                    leadingIcon = {
                        Icon(Icons.Filled.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.padding(top = 6.dp)
                )

                if (selectedMemberIds.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp)
                    ) {
                        selectedMemberIds.forEach { memberUid ->
                            val name = contacts.firstOrNull { (it.userId.ifBlank { it.id }) == memberUid }?.displayName ?: memberUid.take(6)
                            AssistChip(
                                onClick = { selectedMemberIds.remove(memberUid) },
                                label = { Text(name) },
                                trailingIcon = {
                                    Icon(Icons.Filled.Close, contentDescription = "Remove $name", modifier = Modifier.size(14.dp))
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        onCreateGroup(groupTitle, groupDesc, groupPhotoData, selectedMemberIds.toList())
                    },
                    enabled = !isBusy && groupTitle.isNotBlank() && selectedMemberIds.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDeep, contentColor = Color.White),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("confirm_create_group_button")
                ) {
                    Text("Create Group (${selectedMemberIds.size} selected)")
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            OutlinedTextField(
                value = contactQuery,
                onValueChange = { contactQuery = it },
                placeholder = { Text("Search MyChatAp users by name or @handle…") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contact_directory_search_input")
            )

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Discoverable Contacts (${availableContacts.size})",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))

            if (availableContacts.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "No other users found yet",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Sign in from a second Google account or share the app with a friend to start messaging in real time!",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp)
                ) {
                    items(availableContacts, key = { it.userId.ifBlank { it.id } }) { contact ->
                        val uid = contact.userId.ifBlank { contact.id }
                        val isSelected = selectedMemberIds.contains(uid)

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !isBusy) {
                                    if (isGroupMode) {
                                        if (isSelected) selectedMemberIds.remove(uid)
                                        else if (selectedMemberIds.size < 19) selectedMemberIds.add(uid)
                                    } else {
                                        onStartDirectChat(contact)
                                    }
                                }
                                .padding(vertical = 10.dp)
                        ) {
                            AvatarImage(
                                photoData = contact.photoData,
                                displayName = contact.displayName,
                                size = 46.dp,
                                isOnline = contact.isOnline && contact.showLastSeen
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = contact.displayName,
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "@${contact.handle} • ${
                                        if (contact.about.isNotBlank()) contact.about
                                        else TimeFormatUtils.formatPresenceSubtitle(
                                            contact.isOnline,
                                            contact.showLastSeen,
                                            contact.lastSeenAt
                                        )
                                    }",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (isGroupMode) {
                                Icon(
                                    imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                                    contentDescription = if (isSelected) "Selected" else "Not selected",
                                    tint = if (isSelected) EmeraldAccent else MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
