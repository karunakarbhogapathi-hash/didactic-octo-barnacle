package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.model.StatusPost
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.components.AvatarImage
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldDeep
import com.example.util.MediaUtils
import com.example.util.TimeFormatUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val StatusColorHexes = listOf(
    "#075E54",
    "#128C7E",
    "#1D3557",
    "#6D2E46",
    "#2D3142"
)

private fun parseSafeHexColor(hex: String): Color {
    return try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (_: Exception) {
        EmeraldDeep
    }
}

@Composable
fun StatusUpdatesScreen(
    currentUserId: String,
    myProfile: UserProfile?,
    statusesState: UiState<List<StatusPost>>,
    onPostStatus: (mediaType: String, caption: String, imageData: String, bgHex: String) -> Unit,
    onMarkViewed: (StatusPost) -> Unit,
    onDeleteStatus: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showTextComposer by remember { mutableStateOf(false) }
    var pendingPhotoDataUri by remember { mutableStateOf<String?>(null) }
    var viewingAuthorPosts by remember { mutableStateOf<List<StatusPost>?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val encoded = MediaUtils.encodeUriToDataUri(context, uri, maxDimension = 640)
                if (encoded != null) {
                    pendingPhotoDataUri = encoded
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
                .align(Alignment.TopCenter)
        ) {
            when (statusesState) {
                is UiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = EmeraldAccent)
                    }
                }
                is UiState.Error -> {
                    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(statusesState.message, color = MaterialTheme.colorScheme.error)
                    }
                }
                is UiState.Success -> {
                    val allStatuses = statusesState.data
                    val myStatuses = remember(allStatuses, currentUserId) {
                        allStatuses.filter { it.authorId == currentUserId }
                    }
                    val otherGrouped = remember(allStatuses, currentUserId) {
                        allStatuses.filter { it.authorId != currentUserId }
                            .groupBy { it.authorId }
                            .values
                            .toList()
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 120.dp)
                    ) {
                        item {
                            // My Status Header Card
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (myStatuses.isNotEmpty()) {
                                            viewingAuthorPosts = myStatuses
                                        } else {
                                            showTextComposer = true
                                        }
                                    }
                                    .padding(horizontal = 16.dp, vertical = 14.dp)
                                    .testTag("my_status_row")
                            ) {
                                Box {
                                    AvatarImage(
                                        photoData = myProfile?.photoData ?: "",
                                        displayName = myProfile?.displayName ?: "Me",
                                        size = 54.dp,
                                        hasUnseenStatusRing = myStatuses.isNotEmpty()
                                    )
                                    if (myStatuses.isEmpty()) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .size(20.dp)
                                                .clip(CircleShape)
                                                .background(EmeraldAccent),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Add,
                                                contentDescription = null,
                                                tint = Color(0xFF043927),
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = stringResource(R.string.my_status_title),
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = if (myStatuses.isNotEmpty())
                                            "${myStatuses.size} active update(s) • Tap to view"
                                        else stringResource(R.string.my_status_tap_to_add),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                        }

                        item {
                            Text(
                                text = stringResource(R.string.recent_updates_header),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                            )
                        }

                        if (otherGrouped.isEmpty()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "No contact status updates in the last 24 hours",
                                            style = MaterialTheme.typography.titleSmall,
                                            textAlign = TextAlign.Center
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Post a text or photo status using the buttons in the bottom-right corner!",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        } else {
                            items(otherGrouped, key = { it.first().authorId }) { posts ->
                                val latest = posts.first()
                                val hasUnseen = posts.any { !it.viewerIds.contains(currentUserId) }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewingAuthorPosts = posts }
                                        .padding(horizontal = 16.dp, vertical = 11.dp)
                                ) {
                                    AvatarImage(
                                        photoData = latest.authorPhotoData,
                                        displayName = latest.authorName,
                                        size = 52.dp,
                                        hasUnseenStatusRing = hasUnseen,
                                        hasSeenStatusRing = !hasUnseen
                                    )
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = latest.authorName,
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Text(
                                            text = "${posts.size} update(s) • ${TimeFormatUtils.formatChatListTime(latest.createdAt)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                HorizontalDivider(
                                    modifier = Modifier.padding(start = 80.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Dual Status Action FABs (Text Status + Photo Status)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(18.dp)
        ) {
            SmallFloatingActionButton(
                onClick = { showTextComposer = true },
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.testTag("text_status_fab")
            ) {
                Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.post_text_status))
            }

            FloatingActionButton(
                onClick = {
                    photoPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                containerColor = EmeraldAccent,
                contentColor = Color(0xFF043927),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.testTag("photo_status_fab")
            ) {
                Icon(Icons.Filled.PhotoCamera, contentDescription = stringResource(R.string.post_photo_status))
            }
        }
    }

    // Full-screen Text Status Composer
    if (showTextComposer) {
        var statusText by remember { mutableStateOf("") }
        var colorIdx by remember { mutableIntStateOf(0) }
        val activeHex = StatusColorHexes[colorIdx % StatusColorHexes.size]

        Dialog(
            onDismissRequest = { showTextComposer = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(parseSafeHexColor(activeHex))
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { showTextComposer = false }) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White)
                    }
                    IconButton(onClick = { colorIdx++ }) {
                        Icon(Icons.Filled.Palette, contentDescription = "Switch background color", tint = Color.White)
                    }
                }

                OutlinedTextField(
                    value = statusText,
                    onValueChange = { statusText = it },
                    placeholder = {
                        Text(
                            "Type a status…",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 24.sp
                        )
                    },
                    textStyle = MaterialTheme.typography.headlineMedium.copy(
                        color = Color.White,
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.Center)
                        .testTag("status_text_input")
                )

                FloatingActionButton(
                    onClick = {
                        if (statusText.isNotBlank()) {
                            onPostStatus("text", statusText.trim(), "", activeHex)
                            showTextComposer = false
                        }
                    },
                    containerColor = EmeraldAccent,
                    contentColor = Color(0xFF043927),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .testTag("publish_text_status_button")
                ) {
                    Text("Post", modifier = Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Photo Status Caption Dialog
    if (pendingPhotoDataUri != null) {
        var photoCaption by remember { mutableStateOf("") }
        val previewBmp = remember(pendingPhotoDataUri) {
            pendingPhotoDataUri?.let { MediaUtils.decodeDataUriToImageBitmap(it) }
        }
        AlertDialog(
            onDismissRequest = { pendingPhotoDataUri = null },
            title = { Text("Share Photo Status") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (previewBmp != null) {
                        Image(
                            bitmap = previewBmp,
                            contentDescription = "Status photo preview",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(RoundedCornerShape(14.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    OutlinedTextField(
                        value = photoCaption,
                        onValueChange = { photoCaption = it },
                        label = { Text("Add a caption (optional)") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val img = pendingPhotoDataUri ?: ""
                    pendingPhotoDataUri = null
                    onPostStatus("image", photoCaption.trim(), img, "#075E54")
                }) {
                    Text("Share")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingPhotoDataUri = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Story Viewer Dialog
    viewingAuthorPosts?.let { stories ->
        if (stories.isEmpty()) {
            viewingAuthorPosts = null
        } else {
            var currentIndex by remember(stories) { mutableIntStateOf(0) }
            val safeIndex = currentIndex.coerceIn(0, stories.lastIndex)
            val activeStory = stories[safeIndex]

            LaunchedEffect(activeStory.id) {
                onMarkViewed(activeStory)
                delay(5500L)
                if (safeIndex < stories.lastIndex) {
                    currentIndex = safeIndex + 1
                } else {
                    viewingAuthorPosts = null
                }
            }

            Dialog(
                onDismissRequest = { viewingAuthorPosts = null },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                val bg = if (activeStory.mediaType == "text") {
                    parseSafeHexColor(activeStory.backgroundColorHex)
                } else Color.Black

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(bg)
                        .clickable {
                            if (safeIndex < stories.lastIndex) currentIndex = safeIndex + 1
                            else viewingAuthorPosts = null
                        }
                        .padding(18.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        LinearProgressIndicator(
                            progress = { (safeIndex + 1).toFloat() / stories.size.toFloat() },
                            color = EmeraldAccent,
                            trackColor = Color.White.copy(alpha = 0.3f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            AvatarImage(
                                photoData = activeStory.authorPhotoData,
                                displayName = activeStory.authorName,
                                size = 40.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = activeStory.authorName,
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = TimeFormatUtils.formatMessageTime(activeStory.createdAt),
                                    color = Color.White.copy(alpha = 0.78f),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            if (activeStory.authorId == currentUserId) {
                                IconButton(onClick = {
                                    onDeleteStatus(activeStory.id)
                                    viewingAuthorPosts = null
                                }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete status", tint = Color.White)
                                }
                            }
                            IconButton(onClick = { viewingAuthorPosts = null }) {
                                Icon(Icons.Filled.Close, contentDescription = "Close status", tint = Color.White)
                            }
                        }
                    }

                    if (activeStory.mediaType == "image" && activeStory.imageData.isNotBlank()) {
                        val bmp = remember(activeStory.imageData) {
                            MediaUtils.decodeDataUriToImageBitmap(activeStory.imageData)
                        }
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (bmp != null) {
                                Image(
                                    bitmap = bmp,
                                    contentDescription = "Status image",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(16.dp)),
                                    contentScale = ContentScale.FillWidth
                                )
                            }
                            if (activeStory.caption.isNotBlank()) {
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = activeStory.caption,
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleMedium,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        Text(
                            text = activeStory.caption,
                            color = Color.White,
                            style = MaterialTheme.typography.headlineMedium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(horizontal = 20.dp)
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Visibility,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${activeStory.viewerIds.size} view(s)",
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}
