package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// WhatsApp-inspired MyChatAp Brand Palette
val EmeraldDeep = Color(0xFF075E54)
val EmeraldTeal = Color(0xFF128C7E)
val EmeraldAccent = Color(0xFF25D366)
val EmeraldMintContainer = Color(0xFFD8FDD2)
val OnEmeraldMintContainer = Color(0xFF043927)

// Light Theme Surfaces
val LightBackground = Color(0xFFF7FAF8)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEBF2EE)
val LightChatWallpaper = Color(0xFFEFEAE2)
val LightOutgoingBubble = Color(0xFFD9FDD3)
val LightIncomingBubble = Color(0xFFFFFFFF)
val LightTextPrimary = Color(0xFF111B21)
val LightTextSecondary = Color(0xFF54656F)

// Dark Theme Surfaces
val DarkBackground = Color(0xFF0B141A)
val DarkSurface = Color(0xFF111B21)
val DarkTopBar = Color(0xFF1F2C34)
val DarkSurfaceVariant = Color(0xFF202C33)
val DarkChatWallpaper = Color(0xFF0B141A)
val DarkOutgoingBubble = Color(0xFF005C4B)
val DarkIncomingBubble = Color(0xFF202C33)
val DarkTextPrimary = Color(0xFFE9EDEF)
val DarkTextSecondary = Color(0xFF8696A0)

// Status & Semantic Accents
val ReadTickBlue = Color(0xFF34B7F1)
val OnlineDotGreen = Color(0xFF25D366)
val CallDangerRed = Color(0xFFE53935)
