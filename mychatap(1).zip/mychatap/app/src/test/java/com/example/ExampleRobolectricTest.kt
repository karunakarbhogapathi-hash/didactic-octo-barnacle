package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.TimeFormatUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app_name string from context matches MyChatAp`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MyChatAp", appName)
    }

    @Test
    fun `timeFormatUtils detects pure emoji and formats call duration`() {
        assertTrue(TimeFormatUtils.isSingleOrPureEmoji("🔥"))
        assertFalse(TimeFormatUtils.isSingleOrPureEmoji("Hello 🔥"))
        assertEquals("02:05", TimeFormatUtils.formatDurationSeconds(125L))
    }
}
