package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class ChatRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun bootstrapProfile_andObserveDiscoverableProfiles_succeedsForAuthenticatedUser() = runBlocking {
        val uniqueSuffix = UUID.randomUUID().toString().take(8)
        val aliceUid = signInTestUser("alice_$uniqueSuffix@test.com")
        val repository = ChatRepository(firestore, auth)

        val profile = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.ensureProfileBootstrapped("Alice Test", "alice_$uniqueSuffix@test.com")
        }
        assertEquals(aliceUid, profile.userId)

        val profiles = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeDiscoverableProfiles().first { list -> list.any { it.userId == aliceUid } }
        }
        assertTrue(profiles.any { it.userId == aliceUid })
    }

    @Test
    fun directChat_sendMessage_andMarkRead_enforcesParticipantIsolation() = runBlocking {
        val suffix = UUID.randomUUID().toString().take(8)
        val aliceUid = signInTestUser("alice_chat_$suffix@test.com")
        val repo = ChatRepository(firestore, auth)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.ensureProfileBootstrapped("Alice", "alice_chat_$suffix@test.com")
        }

        val bobUid = signInTestUser("bob_chat_$suffix@test.com")
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.ensureProfileBootstrapped("Bob", "bob_chat_$suffix@test.com")
        }

        // Bob creates direct chat with Alice and sends message
        val chatId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.getOrCreateDirectChat(aliceUid, "Alice")
        }
        val msgId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.sendMessage(
                chatId = chatId,
                participantIds = listOf(bobUid, aliceUid),
                senderName = "Bob",
                type = "text",
                text = "Hello from Bob!"
            )
        }
        assertTrue(msgId.isNotBlank())

        // Alice observes messages and marks read
        signInTestUser("alice_chat_$suffix@test.com")
        val messages = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeMessages(chatId, aliceUid).first { list -> list.any { it.id == msgId } }
        }
        assertEquals("Hello from Bob!", messages.first { it.id == msgId }.text)

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.markMessagesRead(chatId, messages, readReceiptsEnabled = true)
        }

        // Eve (non-participant) cannot read Alice & Bob's chat document
        signInTestUser("eve_chat_$suffix@test.com")
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("chats").document(chatId).get().await()
            }
            fail("Expected PERMISSION_DENIED for non-participant Eve")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull("Expected FirebaseFirestoreException, got $e", fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
        }
    }

    @Test
    fun crossUserPrivateSettingsAccess_failsWithPermissionDenied() = runBlocking {
        val suffix = UUID.randomUUID().toString().take(8)
        val aliceUid = signInTestUser("alice_priv_$suffix@test.com")
        val repo = ChatRepository(firestore, auth)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.ensureProfileBootstrapped("Alice", "alice_priv_$suffix@test.com")
        }

        signInTestUser("bob_priv_$suffix@test.com")
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("user_private").document(aliceUid).get().await()
            }
            fail("Expected PERMISSION_DENIED reading another user's user_private document")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull("Expected FirebaseFirestoreException, got $e", fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
        }
    }

    @Test
    fun unauthenticatedCaller_observeDiscoverableProfiles_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = ChatRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeDiscoverableProfiles().first()
            }
            fail("Expected PERMISSION_DENIED for unauthenticated caller")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
        }
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3500L
    }
}
