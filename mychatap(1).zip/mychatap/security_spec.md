# MyChatAp Security Specification (Phase 0 TDD)

## 1. Data Invariants
1. **Authentication Gate**: Zero unauthenticated reads or writes across all collections (`profiles`, `user_private`, `chats`, `messages`, `statuses`, `calls`).
2. **PII Split Isolation**: Sensitive user attributes (`email`, `phoneNumber`, privacy and notification settings) reside exclusively in `/user_private/{userId}`, readable and writable strictly by `request.auth.uid == userId` with `allow list: if false`.
3. **Profile Discovery Boundary**: `/profiles/{userId}` stores only non-PII public chat identity fields (`displayName`, `handle`, `about`, `photoData`, `isOnline`, `isDiscoverable`, `showLastSeen`, `lastSeenAt`). Listing `/profiles` requires `resource.data.isDiscoverable == true`.
4. **Chat Membership Gate**: `/chats/{chatId}` requires `participantIds` bounded between 2 and 20 valid user IDs, with `request.auth.uid in participantIds`. Only participants can read or update message summaries; only group `adminIds` can modify group title, description, photo, or membership.
5. **Message Relational & Denormalized Gate**: Creating `/chats/{chatId}/messages/{messageId}` requires `senderId == request.auth.uid`, valid schema bounds, AND relational verification that `/chats/{chatId}` exists and `request.auth.uid` is in its `participantIds`. Listing messages checks denormalized `request.auth.uid in resource.data.participantIds` without O(n) `get()` calls.
6. **Monotonic Message Status & Immortal Fields**: `senderId`, `chatId`, and `createdAt` are immutable on updates. Message `status` (`sent` -> `delivered` -> `read`) cannot regress once `read`.
7. **Status Visibility Boundary**: `/statuses/{statusId}` requires `authorId == request.auth.uid` on creation/deletion, and restricts `list` to `authorId == request.auth.uid || visibility == 'contacts'`.
8. **Call Terminal State Locking**: `/calls/{callId}` restricts access to the 2 `participantIds`. Once `status` reaches a terminal state (`declined`, `ended`, `missed`), all subsequent updates are blocked.

## 2. Dirty Dozen Adversarial Payloads
1. **Unauthenticated Scrape**: Unauthenticated `list` on `/profiles` or `/chats` -> `PERMISSION_DENIED`.
2. **Cross-User PII Leak**: Alice (`alice_123`) attempts `get` on `/user_private/bob_456` -> `PERMISSION_DENIED`.
3. **Unfiltered Query Scrape**: Authenticated user runs unfiltered `db.collection("profiles").get()` or `db.collection("chats").get()` -> `PERMISSION_DENIED`.
4. **Identity Spoofing on Message Create**: Alice writes a message in `/chats/c1/messages/m1` with `senderId: "bob_456"` -> `PERMISSION_DENIED`.
5. **Orphaned Message Write**: Alice creates a message in `/chats/nonexistent_chat/messages/m1` -> `PERMISSION_DENIED` (blocked by parent `exists()`/`get()` gate).
6. **Non-Participant Chat Intrusion**: Eve (`eve_789`) attempts `get`, `list`, or `update` on `/chats/alice_bob_chat` -> `PERMISSION_DENIED`.
7. **Shadow Field Injection (Ghost Field)**: Alice updates `/profiles/alice_123` adding `isVerified: true` -> `PERMISSION_DENIED` (`hasOnly` & `affectedKeys().hasOnly` gate).
8. **Value Poisoning on Allowlisted Key**: Alice updates `displayName` on `/profiles/alice_123` with an integer `999` or empty string `""` -> `PERMISSION_DENIED` (`isValidProfile(incoming())` wrapper).
9. **Resource Exhaustion (1MB String / Unbounded Array)**: Attacker sends a 250-item `participantIds` array or oversized text message -> `PERMISSION_DENIED`.
10. **Immortal Field Tampering**: Alice updates `createdAt` or `createdBy` on `/chats/c1` -> `PERMISSION_DENIED`.
11. **Message Status Regression**: Participant attempts to revert a `'read'` message back to `'sent'` -> `PERMISSION_DENIED`.
12. **Call Terminal State Re-Opening**: Caller attempts to change an `'ended'` or `'declined'` call in `/calls/call_1` back to `'accepted'` -> `PERMISSION_DENIED`.
